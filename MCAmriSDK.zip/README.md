# MCAMRI  SDK

This SDK provides anything u want.

### Requirements:
1. Xcode 9.0+
2. iOS 8.0+

### Features:
1. Capabilities to parse and validate Push Payment QR code string.
2. Generate Push Payment QR code string.
