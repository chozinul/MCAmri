//
//  MCAmriCalculation.h
//  MCAmriSDK
//
//  Created by Muchamad Chozinul Amri on 5/10/17.
//  Copyright © 2017 Muchamad Chozinul Amri. All rights reserved.
//

#import <Foundation/Foundation.h>

///Calculation of some math operation
@interface MCAmriCalculation : NSObject

///Add two number
- (int) addition:(int) a b:(int) b;

@end
