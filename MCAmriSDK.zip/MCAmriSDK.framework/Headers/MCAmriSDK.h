//
//  MCAmriSDK.h
//  MCAmriSDK
//
//  Created by Muchamad Chozinul Amri on 5/10/17.
//  Copyright © 2017 Muchamad Chozinul Amri. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MCAmriSDK.
FOUNDATION_EXPORT double MCAmriSDKVersionNumber;

//! Project version string for MCAmriSDK.
FOUNDATION_EXPORT const unsigned char MCAmriSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MCAmriSDK/PublicHeader.h>

#import "MCAmriCalculation.h"
